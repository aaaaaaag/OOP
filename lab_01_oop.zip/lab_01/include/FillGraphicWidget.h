//
// Created by denis on 09.03.2021.
//

#ifndef LAB_01_OOP_FILLGRAPHICWIDGET_H
#define LAB_01_OOP_FILLGRAPHICWIDGET_H

#include "Qt/CanvasWidget.h"
#include "DotStruct.h"

void FillGraphicsWidget(CanvasWidget *canvasWidget, mainShape_t *shape);

#endif //LAB_01_OOP_FILLGRAPHICWIDGET_H
