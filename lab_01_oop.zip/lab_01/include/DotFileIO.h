//
// Created by denis on 28.02.2021.
//

#ifndef LAB_01_DOTFILEIO_H
#define LAB_01_DOTFILEIO_H

#include "DotStruct.h"

mainShape_t GetDotsFromFile(char* fileName, int &error);

//int setDotsToFile(std::string fileName, std::vector<myDots> inVDots);


#endif //LAB_01_DOTFILEIO_H
