//
// Created by denis on 28.02.2021.
//

#ifndef LAB_01_OOP_STRINGANALIZATOR_H
#define LAB_01_OOP_STRINGANALIZATOR_H

#include "string"

bool IsInt(const std::string& str);


#endif //LAB_01_OOP_STRINGANALIZATOR_H
